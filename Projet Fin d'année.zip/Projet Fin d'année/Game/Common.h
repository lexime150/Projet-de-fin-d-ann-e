#ifndef COMMON_H
#define COMMON_H

#include <stdio.h>
#include <stdlib.h>
#include <process.h>
#include "string.h"
#define _USE_MATH_DEFINES
#include <math.h>
#include "SFML/Graphics.h"
#include "SFML/Audio.h"
#include "Animation.h"
#include "Save.h"

#define GAME_SCALE 4
#define SCREEN_WIDTH 1920.f
#define SCREEN_HEIGHT 1080.f

#define GRAVITY 900.f
#define BPP 32

#endif // !COMMON_H
